let form = document.getElementById("form");

let todo = JSON.parse(localStorage.getItem("todos")) || [];
display(todo);
form.addEventListener("submit", (e) => {
  e.preventDefault();
  let task = form.task.value;
  let status = form.status.value;
  var date = new Date().toLocaleDateString();
  const time = new Date().toLocaleString('en-US', { hour: 'numeric', minute: 'numeric', hour12: true });
  let data = {};
  if (task && status) {
    data.task = task;
    data.status = status;
    data.date= date;
    data.time= time
    todo.push(data);
    localStorage.setItem("todos", JSON.stringify(todo));
    display(todo);
  } else {
    alert("fill the credentials");
  }
});

function display(todo) {
  let container = document.getElementById("todo-container");
  container.innerHTML = "";
  todo.map((ele, ind) => {
    let main = document.createElement("div");
    main.className = "single-todos";
    let div1= document.createElement("div");
    div1.className = "child1"

    let div2 = document.createElement("div");
    div2.className ='child2';

    let title = document.createElement("h3");
    title.setAttribute("class", `title`);
    title.setAttribute("class", `title${ind}`);
    title.innerText = ele.task;

    let date= document.createElement("p")
    date.innerText= ele.date;

    let time= document.createElement("p");
    time.innerText= ele.time;

    let edit_title = document.createElement("input");
    edit_title.value = ele.task;
    edit_title.style.display = "none";
    edit_title.setAttribute("id", `edit_task`);
    edit_title.setAttribute("class", `edit_task${ind}`);

    let status = document.createElement("input");
    status.setAttribute("class", `status`);
    status.setAttribute("class", `status${ind}`);
    status.setAttribute("type", "checkbox");
    if (ele.status == "complete") {
      status.checked = true;
    }
    status.addEventListener("click", () => {
      toggleStatus(ind, todo);
    });

    let edit_status = document.createElement("select");

    let edit_option0 = document.createElement("option");
    edit_option0.innerText = "select option";

    let edit_option1 = document.createElement("option");
    edit_option1.value = "complete";
    edit_option1.innerText = "Complete";

    let edit_option2 = document.createElement("option");
    edit_option2.value = "incomplete";
    edit_option2.innerText = "Incomplete";

    edit_status.append(edit_option0, edit_option1, edit_option2);
    edit_status.setAttribute("id", `edit_status`);
    edit_status.setAttribute("class", `edit_status${ind}`);
    edit_status.style.display = "none";

    let edit_btn = document.createElement("button");
    edit_btn.className='edit_btn';
    edit_btn.setAttribute("class", `edit_btn${ind}`);
    edit_btn.innerHTML = '<i class="fa-solid fa-pen-to-square"></i>';

    edit_btn.addEventListener("click", () => {
      editTask(ind, todo);
    });

    let del_btn = document.createElement("button");
    del_btn.setAttribute("class", `del_btn`);

    del_btn.innerHTML = '<i class="fa-solid fa-trash"></i>';

    del_btn.addEventListener("click", () => {
      deleteTask(ind, todo);
    });
    div1.append(status,title,edit_status,edit_title)
    div2.append(date,time,edit_btn,del_btn)
    main.append(div1,div2);
    container.append(main);
  });
  localStorage.setItem("todos", JSON.stringify(todo));
}

// for toggle status

function toggleStatus(ind, todo) {
  todo[ind].status == "complete"
    ? (todo[ind].status = "incomplete")
    : (todo[ind].status = "complete");

  display(todo);
}

//for editing todos
let flag = false;
function editTask(ind, todo) {
  
  let edit_task = document.querySelector(`.edit_task${ind}`);
  let title = document.querySelector(`.title${ind}`);

  let status = document.querySelector(`.status${ind}`);
  let edit_status = document.querySelector(`.edit_status${ind}`);
  if (!flag) {
    document.querySelector(`.edit_btn${ind}`).innerHTML = '<i class="fa-solid fa-check fa-lg"></i>';

    title.style.display = "none";
    edit_task.style.display = "block";

    status.style.display = "none";
    edit_status.style.display = "block";

    edit_task.addEventListener("change", (e) => {
      let value = e.target.value;

      todo[ind].task = value;
    });

    edit_status.addEventListener("change", (e) => {
      let value = e.target.value;
      todo[ind].status = value;
    });
    flag = true;
  } else {
    title.innerText = edit_task.value;
    title.style.display = "block";
    edit_task.style.display = "none";

    status.style.display = "block";
    edit_status.style.display = "none";
    document.querySelector(`.edit_btn${ind}`).innerHTML = '<i class="fa-solid fa-pen-to-square"></i>';
    flag = false;
    display(todo);
  }
}

//for deleting todos

function deleteTask(ind, todo) {
  todo.splice(ind, 1);
  display(todo);
}
